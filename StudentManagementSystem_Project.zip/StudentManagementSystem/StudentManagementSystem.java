import java.util.*;
class Student{
    int id; String name;
    Student(int id,String name){this.id=id;this.name=name;}
}
public class StudentManagementSystem{
    static ArrayList<Student> students=new ArrayList<>();
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("\n1.Add\n2.View\n3.Search\n4.Exit");
            int ch=sc.nextInt();
            switch(ch){
                case 1:
                    System.out.print("ID: ");
                    int id=sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name: ");
                    String name=sc.nextLine();
                    students.add(new Student(id,name));
                    break;
                case 2:
                    for(Student s:students) System.out.println(s.id+" "+s.name);
                    break;
                case 3:
                    System.out.print("Search ID: ");
                    int sid=sc.nextInt();
                    boolean f=false;
                    for(Student s:students) if(s.id==sid){System.out.println(s.name);f=true;}
                    if(!f) System.out.println("Not Found");
                    break;
                case 4:System.exit(0);
            }
        }
    }
}
