# Student Management System
Simple Core Java project.